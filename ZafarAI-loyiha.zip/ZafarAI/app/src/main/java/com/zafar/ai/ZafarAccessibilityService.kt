package com.zafar.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * ZAFAR Accessibility Service
 * Bu servis orqali har qanday ilovani va tizimni boshqarish mumkin
 */
class ZafarAccessibilityService : AccessibilityService() {

    companion object {
        var instance: ZafarAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Bildirismalar va ilovalardan kelgan eventlarni kuzatish
        event?.let {
            when (it.eventType) {
                AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                    // Bildirisma kelganda qayta ishlash
                }
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                    // Ilova o'zgarganda
                }
            }
        }
    }

    override fun onInterrupt() {
        instance = null
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    // =================== AMALLAR ===================

    /**
     * Orqaga qaytish (Back tugmasi)
     */
    fun goBack() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    /**
     * Asosiy ekranga qaytish (Home tugmasi)
     */
    fun goHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    /**
     * So'nggi ilovalar
     */
    fun showRecentApps() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    /**
     * Bildirishmalar panelini ochish
     */
    fun openNotificationPanel() {
        performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    }

    /**
     * Tezkor sozlamalar paneli
     */
    fun openQuickSettings() {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    }

    /**
     * Ekranni o'chirish/yoqish
     */
    fun lockScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }

    /**
     * Ekran rasmini olish (Screenshot)
     */
    fun takeScreenshot() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    /**
     * Matnni topish va bosish
     */
    fun clickOnText(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        return findAndClickNode(rootNode, text)
    }

    private fun findAndClickNode(node: AccessibilityNodeInfo, text: String): Boolean {
        // Matnni qidirish
        if (node.text?.toString()?.contains(text, ignoreCase = true) == true ||
            node.contentDescription?.toString()?.contains(text, ignoreCase = true) == true) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            return true
        }

        // Bolalar nodeni tekshirish
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (findAndClickNode(child, text)) return true
        }
        return false
    }

    /**
     * Input maydoniga matn kiritish
     */
    fun typeText(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val editableNode = findEditableNode(rootNode) ?: return false

        val args = android.os.Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        editableNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return true
    }

    private fun findEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findEditableNode(child)
            if (result != null) return result
        }
        return null
    }

    /**
     * Ilova nomiga qarab ochish
     */
    fun openAppByName(appName: String) {
        val pm = applicationContext.packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val apps = pm.queryIntentActivities(intent, 0)
        val matchedApp = apps.firstOrNull { resolveInfo ->
            val label = resolveInfo.loadLabel(pm).toString()
            label.contains(appName, ignoreCase = true)
        }

        if (matchedApp != null) {
            val launchIntent = pm.getLaunchIntentForPackage(
                matchedApp.activityInfo.packageName
            )
            launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            applicationContext.startActivity(launchIntent)
        }
    }

    /**
     * Ekranda swiping (yuqoriga, pastga, chapga, o'ngga)
     */
    fun swipe(direction: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return

        val displayMetrics = resources.displayMetrics
        val width = displayMetrics.widthPixels.toFloat()
        val height = displayMetrics.heightPixels.toFloat()

        val path = Path()
        when (direction.lowercase()) {
            "up" -> {
                path.moveTo(width / 2, height * 0.7f)
                path.lineTo(width / 2, height * 0.3f)
            }
            "down" -> {
                path.moveTo(width / 2, height * 0.3f)
                path.lineTo(width / 2, height * 0.7f)
            }
            "left" -> {
                path.moveTo(width * 0.8f, height / 2)
                path.lineTo(width * 0.2f, height / 2)
            }
            "right" -> {
                path.moveTo(width * 0.2f, height / 2)
                path.lineTo(width * 0.8f, height / 2)
            }
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
            .build()

        dispatchGesture(gesture, null, null)
    }

    /**
     * Ekrandagi barcha matnni o'qish
     */
    fun readScreenContent(): String {
        val rootNode = rootInActiveWindow ?: return "Ekran ma'lumoti yo'q"
        val sb = StringBuilder()
        extractText(rootNode, sb)
        return sb.toString().trim()
    }

    private fun extractText(node: AccessibilityNodeInfo, sb: StringBuilder) {
        node.text?.let { sb.appendLine(it) }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            extractText(child, sb)
        }
    }

    /**
     * WhatsApp'da xabar yuborish
     */
    fun sendWhatsAppMessage(contact: String, message: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = android.net.Uri.parse("https://wa.me/?text=$message")
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            applicationContext.startActivity(intent)
        } catch (e: Exception) {
            // WhatsApp o'rnatilmagan
        }
    }
}
