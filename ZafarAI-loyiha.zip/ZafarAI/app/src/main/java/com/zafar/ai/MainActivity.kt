package com.zafar.ai

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.telephony.SmsManager
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var inputText: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var micButton: ImageButton
    private lateinit var statusText: TextView

    private val messages = mutableListOf<ChatMessage>()
    private val conversationHistory = mutableListOf<JSONObject>()
    private var isListening = false
    private val client = OkHttpClient()

    // API kalitingizni bu yerga kiriting
    private val API_KEY = "YOUR_ANTHROPIC_API_KEY"

    private val SYSTEM_PROMPT = """
        Sen "ZAFAR" — Android telefonni to'liq boshqara oladigan o'zbek tilidagi AI yordamchisan.
        
        FAQAT O'ZBEK TILIDA javob ber.
        
        Sen quyidagi buyruqlarni bajarasan:
        
        📱 QO'NG'IROQ: "Anvarga qo'ng'iroq qil", "Onaga zang ur"
        💬 SMS: "Botirga xabar yubor: kechaman", "Akamga SMS yozib qo'y"
        📲 ILOVALAR: "WhatsApp'ni och", "YouTube'ni ishga tushir", "Telegramni yopish"
        🔊 OVOZ: "Ovozni ko'tar", "Jimjit qil", "Ovozni pasayt"
        📶 TARMOQ: "Wi-Fi'ni o'chir", "Bluetooth'ni yoq"
        ⚙️ SOZLAMALAR: "Sozlamalarni och", "Yorqinlikni kamaytir"
        🔦 FONAR: "Fonarni yoq", "Chiroqni o'chir"
        🔋 BATAREYA: "Batareya holatini ayt", "Tejamkorlik rejimini yoq"
        📸 KAMERA: "Rasm ol", "Kamerani och"
        📋 MA'LUMOT: "Vaqt necha?", "Bugun qaysi kun?"
        
        Javob formatini JSON ko'rinishida qaytargin:
        {
          "javob": "foydalanuvchiga ko'rsatiladigan matn",
          "amal": "none|call|sms|open_app|volume_up|volume_down|mute|wifi_on|wifi_off|bluetooth_on|bluetooth_off|flashlight_on|flashlight_off|open_settings|battery_info|take_photo",
          "parametr": "amal uchun kerakli qiymat (telefon raqam, ilova nomi, xabar matni va h.k.)",
          "parametr2": "qo'shimcha ma'lumot (SMS uchun xabar matni)"
        }
        
        Doim samimiy, qisqa va aniq javob ber. Amalni bajarganingni bildirish uchun javobda tasdiqlash xabarini yoz.
    """.trimIndent()

    companion object {
        private const val PERMISSION_REQUEST_CODE = 100
        var instance: MainActivity? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        setContentView(R.layout.activity_main)

        initViews()
        initTTS()
        initSpeechRecognizer()
        checkPermissions()
        checkSpecialPermissions()
        startBackgroundService()

        addMessage("ZAFAR", "Assalomu alaykum! Men ZAFAR — sizning shaxsiy AI yordamchingizman. Telefoningizni o'zbek tilida boshqaring! Mikrofonni bosib gapiring yoki yozing. 🤖", false)
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerView)
        inputText = findViewById(R.id.inputText)
        sendButton = findViewById(R.id.sendButton)
        micButton = findViewById(R.id.micButton)
        statusText = findViewById(R.id.statusText)

        chatAdapter = ChatAdapter(messages)
        recyclerView.apply {
            adapter = chatAdapter
            layoutManager = LinearLayoutManager(this@MainActivity).apply {
                stackFromEnd = true
            }
        }

        sendButton.setOnClickListener {
            val text = inputText.text.toString().trim()
            if (text.isNotEmpty()) {
                inputText.setText("")
                processUserInput(text)
            }
        }

        micButton.setOnClickListener {
            if (isListening) stopListening() else startListening()
        }
    }

    private fun initTTS() {
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("uz")
            if (tts.isLanguageAvailable(Locale("uz")) < TextToSpeech.LANG_AVAILABLE) {
                tts.language = Locale.getDefault()
            }
        }
    }

    private fun initSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val text = matches[0]
                    addMessage("Siz", text, true)
                    processUserInput(text)
                }
                stopListening()
            }
            override fun onError(error: Int) { stopListening() }
            override fun onReadyForSpeech(params: Bundle?) {
                statusText.text = "🎤 Gapiring..."
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Ovoz tanish mavjud emas", Toast.LENGTH_SHORT).show()
            return
        }
        isListening = true
        micButton.setImageResource(R.drawable.ic_mic_active)
        statusText.text = "🎤 Tinglayapman..."

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_ALSO_RECOGNIZE_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer.startListening(intent)
    }

    private fun stopListening() {
        isListening = false
        micButton.setImageResource(R.drawable.ic_mic)
        statusText.text = "Buyruq bering..."
        speechRecognizer.stopListening()
    }

    fun processUserInput(text: String) {
        addMessage("Siz", text, true)
        statusText.text = "⏳ Ishlamoqda..."

        // API ga so'rov yuborish
        val userMessage = JSONObject().apply {
            put("role", "user")
            put("content", text)
        }
        conversationHistory.add(userMessage)

        val requestBody = JSONObject().apply {
            put("model", "claude-sonnet-4-20250514")
            put("max_tokens", 1000)
            put("system", SYSTEM_PROMPT)
            put("messages", JSONArray(conversationHistory.map { it }))
        }

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("Content-Type", "application/json")
            .addHeader("x-api-key", API_KEY)
            .addHeader("anthropic-version", "2023-06-01")
            .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    addMessage("ZAFAR", "Tarmoq xatosi: ${e.message}", false)
                    statusText.text = "Buyruq bering..."
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string() ?: return
                runOnUiThread {
                    try {
                        val jsonResponse = JSONObject(responseBody)
                        val content = jsonResponse.getJSONArray("content")
                            .getJSONObject(0).getString("text")

                        // JSON parse qilish
                        val clean = content.replace("```json", "").replace("```", "").trim()
                        val parsed = JSONObject(clean)

                        val javob = parsed.getString("javob")
                        val amal = parsed.optString("amal", "none")
                        val parametr = parsed.optString("parametr", "")
                        val parametr2 = parsed.optString("parametr2", "")

                        addMessage("ZAFAR", javob, false)
                        speak(javob)
                        executeAction(amal, parametr, parametr2)

                        // Tarixga qo'shish
                        conversationHistory.add(JSONObject().apply {
                            put("role", "assistant")
                            put("content", content)
                        })

                        statusText.text = "Buyruq bering..."
                    } catch (e: Exception) {
                        addMessage("ZAFAR", "Xatolik: ${e.message}", false)
                        statusText.text = "Buyruq bering..."
                    }
                }
            }
        })
    }

    private fun executeAction(amal: String, parametr: String, parametr2: String) {
        when (amal) {
            "call" -> makeCall(parametr)
            "sms" -> sendSMS(parametr, parametr2)
            "open_app" -> openApp(parametr)
            "volume_up" -> adjustVolume(true)
            "volume_down" -> adjustVolume(false)
            "mute" -> mutePhone()
            "wifi_on" -> toggleWifi(true)
            "wifi_off" -> toggleWifi(false)
            "bluetooth_on" -> toggleBluetooth(true)
            "bluetooth_off" -> toggleBluetooth(false)
            "flashlight_on" -> toggleFlashlight(true)
            "flashlight_off" -> toggleFlashlight(false)
            "open_settings" -> openSettings()
            "battery_info" -> showBatteryInfo()
            "take_photo" -> openCamera()
        }
    }

    private fun makeCall(number: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            == PackageManager.PERMISSION_GRANTED) {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
            startActivity(intent)
        }
    }

    private fun sendSMS(number: String, message: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED) {
            try {
                val smsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(number, null, message, null, null)
                Toast.makeText(this, "SMS yuborildi ✓", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "SMS xatosi: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun openApp(appName: String) {
        val packageName = when {
            appName.contains("whatsapp", true) -> "com.whatsapp"
            appName.contains("telegram", true) -> "org.telegram.messenger"
            appName.contains("youtube", true) -> "com.google.android.youtube"
            appName.contains("instagram", true) -> "com.instagram.android"
            appName.contains("facebook", true) -> "com.facebook.katana"
            appName.contains("tiktok", true) -> "com.zhiliaoapp.musically"
            appName.contains("maps", true) || appName.contains("xarita", true) -> "com.google.android.apps.maps"
            appName.contains("gmail", true) -> "com.google.android.gm"
            appName.contains("chrome", true) -> "com.android.chrome"
            appName.contains("camera", true) || appName.contains("kamera", true) -> "com.android.camera"
            appName.contains("gallery", true) || appName.contains("galereya", true) -> "com.google.android.apps.photos"
            appName.contains("music", true) || appName.contains("musiqa", true) -> "com.google.android.music"
            appName.contains("calculator", true) || appName.contains("kalkulyator", true) -> "com.android.calculator2"
            appName.contains("clock", true) || appName.contains("soat", true) -> "com.android.deskclock"
            else -> null
        }

        if (packageName != null) {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "$appName o'rnatilmagan", Toast.LENGTH_SHORT).show()
            }
        } else {
            // Accessibility orqali ochish
            ZafarAccessibilityService.instance?.openAppByName(appName)
        }
    }

    private fun adjustVolume(increase: Boolean) {
        val audioManager = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        val direction = if (increase) android.media.AudioManager.ADJUST_RAISE
                       else android.media.AudioManager.ADJUST_LOWER
        audioManager.adjustStreamVolume(
            android.media.AudioManager.STREAM_MUSIC,
            direction,
            android.media.AudioManager.FLAG_SHOW_UI
        )
    }

    private fun mutePhone() {
        val audioManager = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        audioManager.ringerMode = android.media.AudioManager.RINGER_MODE_SILENT
        Toast.makeText(this, "Telefon jimjit rejimda 🔕", Toast.LENGTH_SHORT).show()
    }

    private fun toggleWifi(enable: Boolean) {
        val intent = Intent(Settings.ACTION_WIFI_SETTINGS)
        startActivity(intent)
        Toast.makeText(this, "Wi-Fi sozlamalariga o'tdi", Toast.LENGTH_SHORT).show()
    }

    private fun toggleBluetooth(enable: Boolean) {
        val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        startActivity(intent)
    }

    private fun toggleFlashlight(on: Boolean) {
        val cameraManager = getSystemService(CAMERA_SERVICE) as android.hardware.camera2.CameraManager
        try {
            val cameraId = cameraManager.cameraIdList[0]
            cameraManager.setTorchMode(cameraId, on)
        } catch (e: Exception) {
            Toast.makeText(this, "Fonar xatosi: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openSettings() {
        startActivity(Intent(Settings.ACTION_SETTINGS))
    }

    private fun showBatteryInfo() {
        val batteryManager = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val isCharging = batteryManager.isCharging
        val status = if (isCharging) "Zaryadlanmoqda ⚡" else "Zaryadlanmayapti"
        Toast.makeText(this, "Batareya: $level% | $status", Toast.LENGTH_LONG).show()
    }

    private fun openCamera() {
        val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
        startActivity(intent)
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    fun addMessage(sender: String, text: String, isUser: Boolean) {
        messages.add(ChatMessage(sender, text, isUser, System.currentTimeMillis()))
        chatAdapter.notifyItemInserted(messages.size - 1)
        recyclerView.scrollToPosition(messages.size - 1)
    }

    private fun checkPermissions() {
        val permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE
        )
        val notGranted = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, notGranted.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    private fun checkSpecialPermissions() {
        // Accessibility tekshirish
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this,
                "To'liq funksiya uchun Maxsus imkoniyatlarni yoqing",
                Toast.LENGTH_LONG).show()
            Handler(Looper.getMainLooper()).postDelayed({
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }, 2000)
        }

        // Notification Listener tekshirish
        if (!isNotificationListenerEnabled()) {
            Handler(Looper.getMainLooper()).postDelayed({
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }, 4000)
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val service = "${packageName}/${ZafarAccessibilityService::class.java.canonicalName}"
        return Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(service) == true
    }

    private fun isNotificationListenerEnabled(): Boolean {
        return Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
    }

    private fun startBackgroundService() {
        val intent = Intent(this, ZafarBackgroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tts.shutdown()
        speechRecognizer.destroy()
        instance = null
    }
}
