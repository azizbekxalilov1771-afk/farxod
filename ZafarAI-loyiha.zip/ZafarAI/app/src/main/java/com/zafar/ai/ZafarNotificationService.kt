package com.zafar.ai

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * ZAFAR Bildirisma Xizmati
 * Barcha bildirismalarni o'qiydi va AI ga yuboradi
 */
class ZafarNotificationService : NotificationListenerService() {

    companion object {
        var instance: ZafarNotificationService? = null
        val recentNotifications = mutableListOf<NotificationData>()
        const val MAX_NOTIFICATIONS = 50
    }

    data class NotificationData(
        val app: String,
        val title: String,
        val text: String,
        val time: Long,
        val packageName: String
    )

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val appName = getAppName(sbn.packageName)

        if (title.isNotEmpty() || text.isNotEmpty()) {
            val data = NotificationData(
                app = appName,
                title = title,
                text = text,
                time = System.currentTimeMillis(),
                packageName = sbn.packageName
            )

            recentNotifications.add(0, data)

            // Oxirgi 50 ta bildirisma
            if (recentNotifications.size > MAX_NOTIFICATIONS) {
                recentNotifications.removeAt(recentNotifications.size - 1)
            }

            // Muhim bildirismalar uchun foydalanuvchini xabardor qilish
            notifyImportantNotification(data)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // Bildirisma o'chirilganda
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    private fun getAppName(packageName: String): String {
        return when (packageName) {
            "com.whatsapp" -> "WhatsApp"
            "org.telegram.messenger" -> "Telegram"
            "com.instagram.android" -> "Instagram"
            "com.facebook.katana" -> "Facebook"
            "com.google.android.gm" -> "Gmail"
            "com.android.phone" -> "Telefon"
            "com.google.android.apps.messaging" -> "Xabarlar"
            else -> {
                try {
                    val pm = applicationContext.packageManager
                    val appInfo = pm.getApplicationInfo(packageName, 0)
                    pm.getApplicationLabel(appInfo).toString()
                } catch (e: Exception) {
                    packageName
                }
            }
        }
    }

    private fun notifyImportantNotification(data: NotificationData) {
        // WhatsApp, Telegram va SMS bildirmalar muhim
        val importantApps = listOf("com.whatsapp", "org.telegram.messenger",
            "com.google.android.apps.messaging", "com.android.phone")

        if (data.packageName in importantApps) {
            // MainActivity ga xabar yuborish
            MainActivity.instance?.runOnUiThread {
                // Faqat bildirisma haqida xabardor qilish
            }
        }
    }

    /**
     * Oxirgi bildirmalarni olish
     */
    fun getRecentNotificationsText(): String {
        if (recentNotifications.isEmpty()) return "Hozircha yangi bildirma yo'q"

        val sb = StringBuilder("Oxirgi bildirmalar:\n")
        recentNotifications.take(10).forEach { notif ->
            sb.appendLine("• ${notif.app}: ${notif.title} - ${notif.text}")
        }
        return sb.toString()
    }
}
